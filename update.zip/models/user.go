package models

import "gorm.io/gorm"

type User struct {
	gorm.Model
	Username string `gorm:"unique;not null" json:"username"`
	Password string `gorm:"not null" json:"password,omitempty"`
	Tasks    []Task `gorm:"foreignKey:UserID" json:"tasks,omitempty"` // Relasi ke Task
}
